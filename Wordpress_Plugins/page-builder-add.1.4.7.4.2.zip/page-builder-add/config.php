<?php
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ULPB_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

define( 'ULPB_PLUGIN_URL', plugins_url( '',plugin_basename( __FILE__ ) ) );

define( 'ULPB_PLUGIN_DIR_NAME', dirname( plugin_basename( __FILE__ ) ) );

define( 'ULPB_PLUGIN_SLUG',  'ULPB' );

?>