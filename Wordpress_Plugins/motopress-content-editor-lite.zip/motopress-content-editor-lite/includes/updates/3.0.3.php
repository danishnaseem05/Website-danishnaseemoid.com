<?php

if (!defined('ABSPATH')) exit;

MPCEObjectTemplatesLibrary::getInstance()->_addWidgetsAtts();