<?php
if ( ! defined( 'ABSPATH' ) ) exit;
include 'admin/classes/admin.php';
include 'admin/classes/ajax-requests-class.php';

include 'init/init.php';
?>