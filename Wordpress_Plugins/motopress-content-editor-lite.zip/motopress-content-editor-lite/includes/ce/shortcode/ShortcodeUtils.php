<?php

class MPCEShortcodeUtils {}