	<?php
	$checkPBactive = get_post_meta( $post->ID, 'ulpb_page_builder_active', 'true');

	if ($checkPBactive === 'true') {
		echo '<div class="tab-editor switch_button">Switch to Editor</div>';
	} else{
		echo '<div class="tab-pagebuilder switch_button">Switch to PluginOps Page Builder</div>';
	}
	?>