<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div id="">
<div style="padding: 0 12.5%;">
	<select class="analyticsDateRange" style="display: inline-block; margin: 15px 15px;">
		<option value="7">Last 7 Days</option>
		<option value="30">Last 30 Days</option>
		<option value="60">Last 60 Days</option>
		<option value="100">Last 100 Days</option>
	</select>

	<div id="resetAnalyticsBtn" class="resetAnalyticsBtn" style="margin: 15px -92px; display: inline-block;"> Reset Analytics </div>
	<p class="analyticsDeleted"></p>
</div>

<div id="mainAnalyticsContainer">
</div>


</div>